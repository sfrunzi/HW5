import java.util.GregorianCalendar;
import java.util.LinkedList;

/**
 * Class to store a weather report for a specific day, including the date
 * of the reading, temperature readings for the day, and rainfall for the day.
 */
public class DailyWeatherReport {
	private GregorianCalendar date;
	private LinkedList<Double> temperatures, rainfall;
	
	/**
	 * @param date, date of the readings
	 * @param temperatures, linked list of temperature readings for the day
	 * @param rainfall, linked list of rainfall readings for the day
	 */
	public DailyWeatherReport(GregorianCalendar date, LinkedList<Double> temperatures, LinkedList<Double> rainfall) {
		this.date = date;
		this.temperatures = temperatures;
		this.rainfall = rainfall;
	}
	
	/**
	 * Take a month and a year, and produce the sum of readings for either temperature 
	 * or rainfall over all days in the specified month during the specified year.
	 * @param month, month to analyze (0 = January, 1 = February, etc.)
	 * @param year, year to analyze
	 * @param forTemp, true = temperature readings, false = rainfall readings
	 * @return total number of readings for the specified field
	 */
	public double sumForMonth(int month, int year, boolean forTemp) {
		double sum = 0;
		
		if (this.date.get(GregorianCalendar.MONTH) == month
		&& this.date.get(GregorianCalendar.YEAR) == year) {
			if (forTemp) {
				for (double temp : temperatures) sum += temp;
			} else {
				for (double rain : rainfall) sum += rain;
			}
		}
		
		return sum;
	}
	
	/**
	 * Take a month and a year, and produce the total number of readings for either temperature 
	 * or rainfall over all days in the specified month during the specified year.
	 * @param month, month to analyze (0 = January, 1 = February, etc.)
	 * @param year, year to analyze
	 * @param forTemp, true = temperature readings, false = rainfall readings
	 * @return total number of readings for the specified field
	 */
	public double countForMonth(int month, int year, boolean forTemp) {
		if (this.date.get(GregorianCalendar.MONTH) == month
		&& this.date.get(GregorianCalendar.YEAR) == year) {
			if (forTemp) return temperatures.size();
			else return rainfall.size();
		} else return 0;
	}
}

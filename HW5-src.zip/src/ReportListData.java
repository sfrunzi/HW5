import java.util.LinkedList;

/**
 * Class to store a linked list of daily weather reports and do mathematical
 * operations on the readings in these reports.
 */
public class ReportListData implements IReport {
	private LinkedList<DailyWeatherReport> dailyReports;
	
	public ReportListData() {
		this.dailyReports = new LinkedList<DailyWeatherReport>();
	}
	
	public ReportListData(LinkedList<DailyWeatherReport> dailyReports) {
		this.dailyReports = dailyReports;
	}
	
	/**
	 * Add a daily weather report to the list of daily reports.
	 * @param report, daily weather report to add
	 * @return the current instance of ReportList with the added report
	 */
	public IReport addReport(DailyWeatherReport report) {
		dailyReports.add(report);
		return this;
	}
	
	/**
	 * Take a month and a year, and produce the average temperature over
	 * all days in the specified month during the specified year.
	 * @param month, month to analyze (0 = January, 1 = February, etc.)
	 * @param year, year to analyze
	 * @return average temperature over all days in month of year
	 */
	public double getAverageTempForMonth(int month, int year) {
		double sum = 0, count = 0;
		
		for (DailyWeatherReport report : dailyReports) {
			sum += report.sumForMonth(month, year, true);
			count += report.countForMonth(month, year, true);
		}
		
		if (count == 0) return 0;
		else return (sum / count);
	}
	
	/**
	 * Take a month and a year, and produce the total rainfall over
	 * all days in the specified month during the specified year.
	 * @param month, month to analyze (0 = January, 1 = February, etc.)
	 * @param year, year to analyze
	 * @return total rainfall over all days in month of year
	 */
	public double getTotalRainfallForMonth(int month, int year) {
		double sum = 0;
		
		for (DailyWeatherReport report : dailyReports) {
			sum += report.sumForMonth(month, year, false);
		}
		
		return sum;
	}
	
	/*public boolean equals(WeatherMonitor w) {
		return this == w.getDailyReport();
	}*/
}

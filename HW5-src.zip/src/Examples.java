import static org.junit.Assert.*;

import java.util.GregorianCalendar;
import java.util.LinkedList;
import org.junit.Test;

public class Examples {
	LinkedList<Double> may05Temps, may05Rainfall, may07Temps, may07Rainfall, june08Temps, june08Rainfall;
	DailyWeatherReport may05Report, may07Report, june08Report;
	LinkedList<DailyWeatherReport> reportList;
	IReport reports;
	WeatherMonitor monitor;
	LinkedList<Reading> may05Readings, may07Readings, june08Readings;
	Reading may05ReadingOne, may05ReadingTwo, may05ReadingThree, may07ReadingOne, may07ReadingTwo, june08ReadingOne;
	
	public Examples() {			
		may05Temps = new LinkedList<Double>();
		may05Temps.add(72.0);
		may05Temps.add(73.0);
		may05Temps.add(69.0);
		may05Rainfall = new LinkedList<Double>();
		may05Rainfall.add(0.0);
		may05Rainfall.add(0.0);
		may05Rainfall.add(0.5);
		may05Readings = new LinkedList<Reading>();
		may05ReadingOne = new Reading(new Time(9,0), 72.0, 0.0);
		may05ReadingTwo = new Reading(new Time(12,0), 73.0, 0.0);
		may05ReadingThree = new Reading(new Time(18,0), 69.0, 0.5);
		may05Readings.add(may05ReadingOne);
		may05Readings.add(may05ReadingTwo);
		may05Readings.add(may05ReadingThree);
		may05Report = new DailyWeatherReport(new GregorianCalendar(2021, 4, 5), may05Temps, may05Rainfall);
		
		may07Temps = new LinkedList<Double>();
		may07Temps.add(70.2);
		may07Temps.add(71.0);
		may07Rainfall = new LinkedList<Double>();
		may07Rainfall.add(0.1);
		may07Rainfall.add(0.0);
		may07Readings = new LinkedList<Reading>();
		may07ReadingOne = new Reading(new Time(9,0), 70.2, 0.1);
		may07ReadingTwo = new Reading(new Time(12,0), 71.0, 0.0);
		may07Readings.add(may07ReadingOne);
		may07Readings.add(may07ReadingTwo);
		may07Report = new DailyWeatherReport(new GregorianCalendar(2021, 4, 7), may07Temps, may07Rainfall);
		
		june08Temps = new LinkedList<Double>();
		june08Rainfall = new LinkedList<Double>();
		june08Report = new DailyWeatherReport(new GregorianCalendar(2021, 5, 8), june08Temps, june08Rainfall);
		
		reportList = new LinkedList<DailyWeatherReport>();
		reportList.add(may07Report);
		reportList.add(june08Report);
		
		reports = new ReportListData(reportList);
		monitor = new WeatherMonitor(reports);
	}
	
	@Test
	public void test_addDailyReport() {
		WeatherMonitor monitorTest = monitor;
		reportList.add(may05Report);
		monitor.addDailyReport(new GregorianCalendar(2021, 4, 5), may05Readings);
				
		assertEquals(monitor.getDailyReport(), monitorTest.getDailyReport());
	}
	
	@Test
	public void test_averageTempForMonth() {
		reportList.add(may05Report);
		
		double mayAverageTemp = (72.0 + 73.0 + 69.0 + 70.2 + 71.0) / 5;
		assertEquals(mayAverageTemp, monitor.averageTempForMonth(4, 2021), 0.0001);
		assertEquals(0, monitor.averageTempForMonth(5, 2021), 0.0001);
	}
	
	@Test
	public void test_totalRainfallForMonth() {
		reportList.add(may05Report);
		
		double mayTotalRain = 0.0 + 0.0 + 0.5 + 0.1;
		assertEquals(mayTotalRain, monitor.totalRainfallForMonth(4, 2021), 0.0001);
		assertEquals(0, monitor.averageTempForMonth(5, 2021), 0.0001);
	}
}

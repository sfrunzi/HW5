
/**
 * Class to store the hour and minute of a certain time.
 */
public class Time {
	private int hour, minute;
	
	/**
	 * @param hour, hours value of the time
	 * @param minute, minutes value of the time
	 */
	public Time(int hour, int minute) {
		this.hour = hour;
		this.minute = minute;
	}
	
	/** @return hours value of the time */
	public int getHour() { return hour; }
	
	/** @return minutes value of the time */
	public int getMinute() { return minute; }
}

import java.util.GregorianCalendar;
import java.util.LinkedList;

/**
 * Class to store data about two weather report trends: 
 * average daily temperature and total rainfall during a particular month.
 */
public class WeatherMonitor {
	private IReport dailyReports;
	
	public WeatherMonitor(IReport dailyReports) {
		this.dailyReports = dailyReports;
	}

	/**
	 * Take a month and a year, and produce the average temperature over
	 * all days in the specified month during the specified year.
	 * @param month, month to analyze (0 = January, 1 = February, etc.)
	 * @param year, year to analyze
	 * @return average temperature over all days in month of year
	 */
	public double averageTempForMonth(int month, int year) {
		return dailyReports.getAverageTempForMonth(month, year);
	}
	
	/**
	 * Take a month and a year, and produce the total rainfall over
	 * all days in the specified month during the specified year.
	 * @param month, month to analyze (0 = January, 1 = February, etc.)
	 * @param year, year to analyze
	 * @return total rainfall over all days in month of year
	 */
	public double totalRainfallForMonth(int month, int year) {
		return dailyReports.getTotalRainfallForMonth(month, year);
	}
	
	/**
	 * Take a date and a list of readings (nominally for the specified date)
	 * and store a daily report for the specified date.
	 * @param date, date to store a report for
	 * @param readings, linked list of readings
	 */
	public void addDailyReport(GregorianCalendar date, LinkedList<Reading> readings) {
		LinkedList<Double> temperature = new LinkedList<Double>();
		LinkedList<Double> rainfall = new LinkedList<Double>();
		
		for (Reading reading : readings) {
			temperature.add(reading.getTemperature());
			rainfall.add(reading.getRainfall());
		}
		
		dailyReports.addReport(new DailyWeatherReport(date, temperature, rainfall));
	}
	
	public IReport getDailyReport() {
		return this.dailyReports;
	}
	
}

/**
 * Class to store weather sensor reading data, including the time 
 * of the reading (hour and minute), temperature in degrees Fahrenheit,
 * and the amount of rainfall since the last reading.
 */
public class Reading {
	private Time time;
	private double temperature, rainfall;
	
	/**
	 * @param time, time of the reading (hour and minute)
	 * @param temperature, temperature in degrees Fahrenheit
	 * @param rainfall, amount of rainfall since last reading
	 */
	public Reading(Time time, double temperature, double rainfall) {
		this.time = time;
		this.temperature = temperature;
		this.rainfall = rainfall;
	}
	
	/** @return time of the reading (hour and minute) */
	public Time getTime() { return time; }
	
	/** @return temperature in degrees Fahrenheit */
	public double getTemperature() { return temperature; }
	
	/** @return amount of rainfall since last reading */
	public double getRainfall() { return rainfall; }
}

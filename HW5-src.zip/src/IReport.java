/**
 * Interface for methods intended for usage on weather reports.
 */
public interface IReport {
	public IReport addReport(DailyWeatherReport report);
	public double getAverageTempForMonth(int month, int year);
	public double getTotalRainfallForMonth(int month, int year);
	//public boolean equals(WeatherMonitor w);
}
